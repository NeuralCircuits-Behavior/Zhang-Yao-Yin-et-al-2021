SetPulsePalVoltage(3,3.3);
pause(0.05)
SetPulsePalVoltage(3,0);