
function FilterStr=GetFilterString
FilterStr=['`' 'a' 'b' 'c' 'd' 'e' 'f' 'g' 'h' 'i'];
end