function  [FocusMove,Direction]=getFocusMove(PreviousMag,CurrentMagnification)


if (CurrentMagnification==0.63 & PreviousMag==1.6) | (CurrentMagnification==1.6 & PreviousMag==0.63)
%     FocusMove=12188;
    FocusMove=9641;
elseif (CurrentMagnification==1.6 & PreviousMag==6.3) | (CurrentMagnification==6.3 & PreviousMag==1.6)
%     FocusMove=1722;2541
    FocusMove=2541;
elseif (CurrentMagnification==0.63 & PreviousMag==6.3) | (CurrentMagnification==6.3 & PreviousMag==0.63)
%     FocusMove=1722+12188;
    FocusMove=2541+9641;
else
    FocusMove=0;
end


if CurrentMagnification>PreviousMag
    Direction=-1;
else
    Direction=1;
end
    
end