


tic
Folder='D:\WholeBrainImagingData\20190627_H194_ThreeMag\Stack_8\';
FirstImageNow=1;
ImagesPerStack=100;
Tag=1;

ImStack=zeros(2048,2048,100);
parfor n=FirstImageNow:FirstImageNow+ImagesPerStack-1
    try
        NameNow=[Folder,'\','Image',num2str(Tag),'_',num2str(n),'.tif'];
        CurrentImage=loadTifFast(NameNow);
        %                 IndexB=CurrentImage>OriginalImage;
        %                 OriginalImage(IndexB)=CurrentImage(IndexB);
%         m=n-FirstImageNow+1;
        ImStack(:,:,n)=CurrentImage;
    catch
        %                 break;
    end
end

toc