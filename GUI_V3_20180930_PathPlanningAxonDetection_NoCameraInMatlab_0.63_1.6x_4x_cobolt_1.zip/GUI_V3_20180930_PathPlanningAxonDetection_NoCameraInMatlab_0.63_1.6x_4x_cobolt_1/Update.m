


SavedFoldName=[handles.SaveFolderPath.String,'\'];    
if ~exist(SavedFoldName,'dir')
    mkdir(SavedFoldName);
end
%%
% [classObj]=GetValueNormal(handles);
[classObj,objLightStage]=GetValueNormal(handles);

%% Initialize move parameters
[Xstep, Xcycle ,Ystep ,Ycycle ,Zstep ,Zcycle ,Zdifference,CutStepReady ,CutStepCutting, MaxCuttingThickness,Zoverlap,Zcut]=GetValueMove(handles);

if mod(Zcut,Zstep)
    warning('Please make sure mod(Zut,Zstep)==0');
end
    
Zstacks=ceil(Zstep*Zcycle/Zcut);
% SlicesPerStack=Zcut/Zstep+1;
SlicesPerStack=Zcut/Zstep;
SlicesLastStack=SlicesPerStack; %mod(Zcycle,SlicesPerStack);

    % Xstep: Move X step 
    % Ystep: Move Y step
    % Zstep: Move Z step
    % Xcycle: X cycle
    % Ycycle: Y cycle
    % Zcycle: Z Cycle
    % Zdifference: Distance between light and the blade. Positive: Negative
    % CutStepReady: Move step before cutting
    % CutStepCutting: Move step in cutting
    % MaxCuttingThickness: Max cutting thickness permitted
    % Zoverlap:Overlap between adjacent stacks. 
%% Initialize Path Planning
if handles.Planning.Value==1
    CurrentMagnification= str2num(handles.Magnification.String{handles.Magnification.Value}(1:end-1));
    LowMagnification=str2num(handles.PlanningMag.String{handles.PlanningMag.Value}(1:end-1)); % for planning
    DownfactorXY=1;
    DownfactorZ=1;
    MagLow=str2num(handles.PlanningMag.String{handles.PlanningMag.Value}(1:end-1));
    MagImaging=str2num(handles.ImagingMag.String{handles.ImagingMag.Value}(1:end-1));
    MagImaging1=str2num(handles.ImagingMag.String{handles.ImagingMag2.Value}(1:end-1));
    
    OverlapImaging=str2num(handles.OverlapImaging.String);
    OverlapPlanning=str2num(handles.OverlapPlanning.String);
    CutoffSignal=str2num(handles.SignalThreshold.String);
    CutoffImagingRatio=str2num(handles.SignalRatio.String);
    ShowPlanning=1;
    PlaningLightColor=handles.LightColor.String{handles.LightColor.Value}; 
    PlanningETLVoltageLeft=eval(handles.PlanningLeftETLVoltage.String);
    PlanningETLVoltageRight=eval(handles.PlanningRightETLVoltage.String);
    
    OverlapImaging1=str2num(handles.OverlapImaging2.String);
    CutoffSignal1=str2num(handles.SignalThreshold2.String);
    CutoffImagingRatio1=str2num(handles.SignalRatio2.String);
  
    
    ResolutionProgramme=GetResolution(MagLow);
%     if MagLow==0.63
%        ResolutionProgramme=5.1760;  % resolution in the programmed magnification. um/pixel 
%     elseif MagLow==2
%        ResolutionProgramme=1.63728;
%     end
    ResolutionImaging=GetResolution(MagImaging);
    FOVImaging=ResolutionImaging*2048; % Field of view in the imaging magnification. um
    StepStageOld=FOVImaging - FOVImaging*OverlapImaging/100; % Step real size, um

    Xstep=StepStageOld;
    % 2x to 0.63x
%     FocusMoveHightLow=12263; 
%     FocusMoveLow2High=12263;
    % 2.5x to 0.63x
%     FocusMoveHightLow=12245; 
%     FocusMoveLow2High=12245;
    % 4x to 0.63x  % note
%     FocusMoveHigh2Low=11196;
%     FocusMoveLow2High=11196;
    % 1.6x to 0.63x  12188 5mm DippingCap 
    FocusMoveHigh2Low=12188;
    FocusMoveLow2High=12188;   
      % 1.6x to 0.63x  6.5mm Dipping Cap
%     FocusMoveHigh2Low=9641;
%     FocusMoveLow2High=9641;
 

    
      % from 1.6 to 4  5mm DippingCap
    FocusMoveHigh2Low1=1722;
    FocusMoveLow2High1=1722;
    
       % from 1.6 to 4  7mm DippingCap
%     FocusMoveHigh2Low1=2002;
%     FocusMoveLow2High1=2002;
    
       % from 1.6 to 4  6.5mm DippingCap
%     FocusMoveHigh2Low1=2179;
%     FocusMoveLow2High1=2179;
       % from 1.6 to 6.3  6.5mm DippingCap
%     FocusMoveHigh2Low1=1827;
%     FocusMoveLow2High1=1827;

%     FocusMoveHigh2Low1=1735;
%     FocusMoveLow2High1=1735;
    
    if strcmp(PlaningLightColor,'Blue')
        PlanningColorLeft=1;
        PlanningColorRight=2;
    elseif strcmp(PlaningLightColor,'Red')
        PlanningColorLeft=3;
        PlanningColorRight=4;
    end
    % 2.5x to 0.63
%     HighPixel=[1192 1060];
%     LowPixel=[1024 1024];
      % 4x to 0.63
%     HighPixel=[1329 1086];
%     HighPixel=[1356 1116];
%     LowPixel=[1024 1024];
   
   % for second round planning
   HighPixel=[1110 1080];
   LowPixel=[1024 1024];
%    1080 1110
   
   % for final imaging 4x 
   HighPixel1=[1291 1212];
   LowPixel1=[1110 1080];

   % for final imaging 6.3x 
%    HighPixel1=[1470 1333];
%    LowPixel1=[1110 1080];
%    [1333 1470]

    
    % agarose reference name
    ReferenceName.TopLeft='';
    ReferenceName.TopRight='';
    ReferenceName.DownRight='';
    ReferenceName.DownLeft='';
end
%% 
TimeConstant=200;
    
    
%% Initialize sleep time
[SleepTime8 ,SleepTime1 ,SleepTime10 ,SleepTime11 ,SleepTime12 ,SleepTime2X,SleepTime2Y,SleepTime2Z,SleepTime3X,SleepTime3Y,SleepTime4,SleepTime5,SleepTime6,SleepTime7,SleepTime9,SleepTimeCut2]=GetValueSleepTime(handles);
    

    % SleepTime1: Set SpeedTime
    % SleepTimeCut2: Return Z time
    % SleepTime2X: Move X. 5000ms for 8000step;
    % SleepTime2Y: Move Y. 5000ms for 8000step;
    % SleepTime2Z: Move Z. 5000ms for 8000step;
    % SleepTime3X: Reture to Zero X 6000;
    % SleepTime3Y: Reture to Zero Y.
    % SleepTime4: Cut time ready
    % SleepTime5: Cut time cutting
    % SleepTime6: Return to zero(imaging) after cut
    % SleepTime10: Cutting return to the cut start point in Normal Speed(255) time 
    % SleepTime7: Imaging delay after opening light
    % SleepTime8: Light closing delay after Imaging 
    % SleepTime9: Filter Transfer
    % SleepTime11: Move MaxCuttingThickness in Z;
    % SleepTime12: Move Zdifference time;
%% initialize cameral parameters
[Snap ,ExposureDefault ,ExposureBlueLeft ,ExposureBlueRight ,ExposureYellowLeft ,ExposureYellowRight ,ExposureRedLeft ,ExposureRedRight]=GetValueCamera(handles);

% This is a trick. Setting the ExposureBlue and ExposureRed as a one dimensional vector can facilitate the following procedure. It does not have any meaning. 
if ExposureDefault==1
    ExposureBlueLeft=[100];
    ExposureRedLeft=[100];
    ExposureYellowLeft=[100];
    ExposureBlueRight=[100];
    ExposureRedRight=[100];
    ExposureYellowRight=[100];
end

    % Snap; Snap(1) or not  
    % ExposureDefault: If the ExposureDefault equals to 1, the exposure time would be the current set exposure time, otherwise it would use the exposure time we set.
    % Exposure*: Exposure time for each side and each light. 

%% Initialize stage move parameters
[Normalspeed, CutspeedReady, CutspeedCutting,Acceleration]=GetSpeed(handles);

TranslationXP=Xstep*-1;
TranslationXN=Xstep;
TranslationYP=Ystep*-1;
TranslationYN=Ystep;
TranslationZP=Zstep*-1;
TranslationZN=Zstep;
TranslationZT=Zcut*-1;
TranslationZTN=Zcut;

TranslationCutReadyS=CutStepReady; % long 
TranslationCutReadyL=(CutStepReady+(Xcycle-1)*Xstep); % short

TranslationCutCutting=CutStepCutting;
CutReturnS=(CutStepReady+CutStepCutting)*-1;
CutReturnL=(CutStepReady+(Xcycle-1)*Xstep+CutStepCutting)*-1;

TranslationCutReturnS=abs(CutReturnS)*-1;
TranslationCutReturnL=abs(CutReturnL)*-1;

TranslationReturnZ=Zoverlap;
ReturnZmove=300/1000; %default 300
ReturnZmoveReverse=300/1000*-1; %default 300

TranslationZdifference=Zdifference;
TranslationZdifferenceReverse=Zdifference*-1;



%% Initialize filter parameters
FilterStr=GetFilterString;
FilterBlue=handles.BlueFilter.Value;
FilterYellow=handles.YellowFilter.Value;
FilterRed=handles.RedFilter.Value;
Wheel = instrfind('Type', 'serial', 'Port', handles.my.WheelPort, 'Tag', '');




%% Initialize light parameters
[LeftImaging,RightImaging,BlueImaging,YellowImaging,RedImaging,LeftImaging1,RightImaging1]=GetValueImaging(handles);

if handles.ContinuslyMove.Value==1
    SnapTag='SnapAZStackSingleChannelContinuously';
    if BlueImaging==1
        ColorLeft=1;
        ColorRight=2;
    elseif RedImaging==1
        ColorLeft=3;
        ColorRight=4;
    elseif YellowImaging==1
        ColorLeft=3;
        ColorRight=4;
    end
else
    if BlueImaging+YellowImaging+RedImaging==5
        SnapTag='SnapAZStackSingleChannel';
        if BlueImaging==1
            ColorLeft=1;
            ColorRight=2;
        elseif RedImaging==1
            ColorLeft=3;
            ColorRight=4;
        elseif YellowImaging==1
            ColorLeft=3;
            ColorRight=4;
        end
    else
        SnapTag='SnapAZStackMultiChannel';
        ColorLeft=1;
        ColorRight=2;
    end
end
%% Voltage change with Y
% VoltageLeft=[];
% VoltageRight=[];
MaxErrorPermitted=30;
%% snap combine
% [Snapcombine,VoltageSampledLeft,VoltageSampledRight]=GetValueSnapCombine(handles);
% if ~exist('j')  |  exist('j')==5
%     j=1;
% end
% VoltageSampledLeftN=VoltageSampledLeft(j,:);
% VoltageSampledRightN=VoltageSampledRight(j,:);

% external trigger of cameral
% Exposure=str2num(handles.ExposureEdit.String);
SetCameralTriggerTrain;

    % Snapcombine: Snapcombine(1) or not.
    % VoltageSampledLeft: Sampled voltage for left light, from small to big
    % VoltageSampledRight: Sampled voltage for Right light, from big to small
%% Initial move direction
XdirectionI=1;% 1 from left to right; -1 from right to left (X axis)
YdirectionI=1;% 1 from top to down; -1 from down to top (Y axis)
ZdirectionI=1;% 1 from top to down; -1 form down to top( Z axis)
SaveFolder='D:\WholeBrainImagingData\20210106_Y81_HY_4x_2um\Stack_15\';

%% Color Intensity
ColorIntensityLowMagRight=10;
ColorIntensityLowMagLeft=10;
ColorIntensityHighMagLeft=10;
ColorIntensityHighMagRight=10;

%% get voltage train

[PlanningLeftETLVoltage,PlanningRightETLVoltage,VoltageSampledLeft,VoltageSampledRight,VoltageSampledLeft1,VoltageSampledRight1]=GetVoltageTrain(handles);

%% light stage current state -1 left light open, 1 right light open
CoboltShutterChannel=1; % related to pulsepal new for cobolt shutter control