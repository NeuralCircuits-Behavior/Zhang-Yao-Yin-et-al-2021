function SaveAData(SaveFolder,SaveName,ImageLastNum)

save([SaveFolder,'\',SaveName],ImageLastNum);

end