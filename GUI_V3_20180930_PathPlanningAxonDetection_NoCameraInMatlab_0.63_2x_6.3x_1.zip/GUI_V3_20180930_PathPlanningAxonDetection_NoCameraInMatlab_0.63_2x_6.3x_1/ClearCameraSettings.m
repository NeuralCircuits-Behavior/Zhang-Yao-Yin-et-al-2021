stop(vid)

vid.FramesAvailable


im = getdata(vid);
