



for i=1:4
    classObj.MoCtrCard_MCrlAxisRelMove(0,24,0.3,0.4);
    pause(73);
    classObj.MoCtrCard_MCrlAxisRelMove(2,0.5,3,3);
    pause(1.5);
    classObj.MoCtrCard_MCrlAxisRelMove(0,-24,3,3);
    pause(10);
    classObj.MoCtrCard_MCrlAxisRelMove(2,-0.8,3,3);
    pause(1.5);
    
end