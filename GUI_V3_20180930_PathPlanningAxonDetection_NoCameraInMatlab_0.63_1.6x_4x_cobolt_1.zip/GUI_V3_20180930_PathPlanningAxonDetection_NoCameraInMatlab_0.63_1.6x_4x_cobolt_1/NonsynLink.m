ProgramPulsePalParam(1, 12, 0); % 'LinkedToTriggerCH1';
ProgramPulsePalParam(2, 12, 0); 
ProgramPulsePalParam(3, 12, 1); 
ProgramPulsePalParam(4, 12, 0); 

ProgramPulsePalParam(1, 13, 0); % 'LinkedToTriggerCH2';
ProgramPulsePalParam(2, 13, 0); 
ProgramPulsePalParam(3, 13, 0); 
ProgramPulsePalParam(4, 13, 0); 