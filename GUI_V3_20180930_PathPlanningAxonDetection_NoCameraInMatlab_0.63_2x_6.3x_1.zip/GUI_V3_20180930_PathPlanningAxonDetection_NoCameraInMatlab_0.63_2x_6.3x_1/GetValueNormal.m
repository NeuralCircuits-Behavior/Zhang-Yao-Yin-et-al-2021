function [classObj]=GetValueNormal(handles)
    classObj=handles.my.classObj;
end