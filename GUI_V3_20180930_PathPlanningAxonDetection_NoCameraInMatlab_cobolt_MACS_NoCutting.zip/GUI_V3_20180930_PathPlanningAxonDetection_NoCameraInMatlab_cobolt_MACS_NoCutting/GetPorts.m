
function [PulsePalPort PulsePalNewPort StagePort WheelPort VibratomePort,FocusPort]=GetPorts()
    PulsePalPort='COM11';
    PulsePalNewPort='COM12';
    StagePort='COM30';
    WheelPort='COM5';
    VibratomePort='COM255';
    FocusPort='COM2';
end