function  LightStageCurrentState=OpenLight(LightStageCurrentState,MoveState,objLightStage,CoboltShutterChannel)

% LightStageCurrentState: -1 left light is currently open; 1 right light is
% currently open

if LightStageCurrentState~=MoveState
   if  LightStageCurrentState==-1 & MoveState==1
       Str='BB B1 01 0D 01 F4 00 EE' %�POS 20mm, v=13 RIGHT
       D   = sscanf(Str, '%2x');
       fwrite(objLightStage, D, 'uint8')
       pause(2)
   elseif LightStageCurrentState==1 & MoveState==-1
       Str='BB B1 00 0D 01 F4 00 EE' %�NEG 20mm, v=13 LEFT
       D   = sscanf(Str, '%2x');
       fwrite(objLightStage, D, 'uint8')
       pause(2)
   else
       error('unrecognized MoveState or LightStageCurrentState')
   end 
end
LightStageCurrentState=MoveState;
% open shutter 
SetPulsePalVoltageNew(CoboltShutterChannel,5); 

end