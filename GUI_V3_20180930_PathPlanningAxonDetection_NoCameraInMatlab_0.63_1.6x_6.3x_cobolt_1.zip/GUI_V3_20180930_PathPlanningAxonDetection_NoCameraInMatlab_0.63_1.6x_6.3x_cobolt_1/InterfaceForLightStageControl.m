% changed
%%
a=get(0,'UserData');
objLightStage=a.objLightStage;
CoboltShutterChannel=1;

LightStageCurrentState=1;
% the current light state. -1 left light open; 1 right light open
%% left light open
MoveState=-1;
LightStageCurrentState=OpenLight(LightStageCurrentState,MoveState,objLightStage,CoboltShutterChannel)

%% right light open
MoveState=1;
LightStageCurrentState=OpenLight(LightStageCurrentState,MoveState,objLightStage,CoboltShutterChannel)
%% shutter open/close
SetPulsePalVoltageNew(CoboltShutterChannel,5);  % open
SetPulsePalVoltageNew(CoboltShutterChannel,0);  % close

%%
LightStageCurrentState=-1;
% right light open
MoveState=1;
LightStageCurrentState=OpenLight(LightStageCurrentState,MoveState,objLightStage,CoboltShutterChannel)
