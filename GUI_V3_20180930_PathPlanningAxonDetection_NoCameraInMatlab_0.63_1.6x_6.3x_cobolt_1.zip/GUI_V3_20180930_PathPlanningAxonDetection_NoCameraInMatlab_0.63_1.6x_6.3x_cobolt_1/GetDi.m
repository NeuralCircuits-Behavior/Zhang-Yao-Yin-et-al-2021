function Di=GetDi(Direction)

   if Direction>0
       Di=1;
   elseif Direction<0
       Di=0;
   end
   

end