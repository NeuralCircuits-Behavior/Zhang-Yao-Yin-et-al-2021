function [classObj,objLightStage]=GetValueNormal(handles)
    classObj=handles.my.classObj;
    objLightStage=handles.my.objLightStage;
end
